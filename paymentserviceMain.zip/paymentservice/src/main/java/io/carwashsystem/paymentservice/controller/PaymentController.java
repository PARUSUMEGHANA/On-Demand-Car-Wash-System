package io.carwashsystem.paymentservice.controller;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.carwashsystem.paymentservice.exception.ApiRequestException;
import io.carwashsystem.paymentservice.model.PaymentDetails;
import io.carwashsystem.paymentservice.repo.PaymentRepository;
import io.carwashsystem.paymentservice.service.PaymentService;

@RestController
@RequestMapping("/payment")
public class PaymentController {
    @Autowired
    public PaymentService service;

    @Autowired
    public PaymentRepository repo;
    
    @CrossOrigin(origins = "http://localhost:4200")
    @PostMapping("/addpayment")
//    public PaymentDetails doPayment(@RequestBody PaymentDetails payment){
//        return service.doPay(payment);
//    }
    
    public ResponseEntity<String> doPay( @RequestBody PaymentDetails payment) {
		try {
	 		payment = service.doPay(payment);
	 		String result = "Payment is processed Successfully with " + payment;
	 		return new ResponseEntity<String>(result, HttpStatus.CREATED);
	 	}
	 	catch(NoSuchElementException e){
	 		return new ResponseEntity<>(HttpStatus.CONFLICT);
	 		
	 	}
	 }
    
    @CrossOrigin(origins = "http://localhost:4200")
	 @PutMapping("/updatepayment/{id}")
	 public ResponseEntity<Object> updatepayment(@PathVariable int id,  @RequestBody PaymentDetails payment )
	 {
	 	 boolean isPaymentExist=repo.existsById(id);
		 if(isPaymentExist) {
		 	repo.save(payment);
		    	return new ResponseEntity<Object>("Payment Updated Successfully with id "+id,HttpStatus.OK);
		 }
		 else
		 {
			 throw new ApiRequestException("CAN NOT UPDATE AS PAYMENT NOT FOUND WITH THIS ID ::");
		 }
	 }
}
