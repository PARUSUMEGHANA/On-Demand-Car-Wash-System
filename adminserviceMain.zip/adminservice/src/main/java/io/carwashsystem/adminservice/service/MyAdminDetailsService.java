package io.carwashsystem.adminservice.service;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import io.carwashsystem.adminservice.model.AdminDetails;
import io.carwashsystem.adminservice.repo.AdminRepository;

import java.util.ArrayList;

@Service
public class MyAdminDetailsService implements UserDetailsService {
	
	@Autowired
	private AdminRepository repository;

    @Override
    public UserDetails loadUserByUsername(String name) throws UsernameNotFoundException {
      AdminDetails admin=repository.findByName(name);
       
      return new User(admin.getName(),admin.getPassword(),new ArrayList<>());
    	
    }
}
