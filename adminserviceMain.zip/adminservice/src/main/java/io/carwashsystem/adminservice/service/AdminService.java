package io.carwashsystem.adminservice.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import io.carwashsystem.adminservice.model.AdminDetails;
import io.carwashsystem.adminservice.repo.AdminRepository;

@Service
public class AdminService {

	@Autowired
	private AdminRepository repository;
	

	public AdminDetails addAdmin(AdminDetails admin) {
		return repository.save(admin);
	}

	public List<AdminDetails> getAdmins() {
		List<AdminDetails> admins = repository.findAll();
		System.out.println("Getting data from DB : " + admins);
		return admins;
	}
	public void deleteAdmin(AdminDetails admin) {
		repository.delete(admin);
	}

	public void deleteById(int id) {
		repository.deleteById(id);
		
	}
}

