package io.carwashsystem.adminservice.controller;

import java.io.IOException;
import java.util.List;
import java.util.Optional;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import io.carwashsystem.adminservice.model.AdminDetails;
import io.carwashsystem.adminservice.model.Ratings;
import io.carwashsystem.adminservice.model.WashPacks;
import io.carwashsystem.adminservice.repo.AdminRepository;
import io.carwashsystem.adminservice.repo.RatingRepository;
import io.carwashsystem.adminservice.repo.WashPackRepository;
import io.carwashsystem.adminservice.service.AdminService;
import io.carwashsystem.adminservice.service.MyAdminDetailsService;
import io.carwashsystem.adminservice.util.JwtUtil;
import io.carwashsystem.adminservice.exception.ApiRequestException;
import io.carwashsystem.adminservice.model.WasherDetails;
import io.carwashsystem.adminservice.model.AuthenticationRequest;
import io.carwashsystem.adminservice.model.AuthenticationResponse;


@RestController
@RequestMapping("/admin/")
public class AdminController {
	
	@Autowired
	private AdminRepository repo;
	
	@Autowired
	private WashPackRepository repo1;
	
	@Autowired
	private RatingRepository repo2;
	
	
	@Autowired
	private AdminService service;
	
	@Autowired
	private AuthenticationManager authenticationManager;

	@Autowired
	private JwtUtil jwtTokenUtil;

	@Autowired
	private MyAdminDetailsService adminDetailsService;
	
	@Autowired
	private RestTemplate restTemplate;

	@Autowired
	private PasswordEncoder passwordEncoder;
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@RequestBody AuthenticationRequest authenticationRequest) throws Exception {

		try {
			authenticationManager.authenticate(
					new UsernamePasswordAuthenticationToken(authenticationRequest.getUsername(), authenticationRequest.getPassword())
			);
		}
		catch (BadCredentialsException e) {
			throw new Exception("Incorrect username or password", e);
		}


		final UserDetails userDetails = adminDetailsService
				.loadUserByUsername(authenticationRequest.getUsername());

		final String jwt = jwtTokenUtil.generateToken(userDetails);

		return ResponseEntity.ok(new AuthenticationResponse(jwt));
	 }
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addadmin")
	public String saveadmin(@Valid @RequestBody AdminDetails admin) {
    admin.setPassword(this.passwordEncoder.encode(admin.getPassword()));
		repo.save(admin);
		return " Admin saved successfully with id :"+admin.getId();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/alladmins")
	public List<AdminDetails> getadmin()
	{
		return repo.findAll();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/alladmins/{id}")
	public Optional<AdminDetails> getadmin(@PathVariable int id)
	{
		return repo.findById(id);
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	 @GetMapping("/adminexist/{id}")
	 public ResponseEntity<Object> updateadmin(@PathVariable int id )
	 {
	 	 boolean isAdminExist=repo.existsById(id);
		 if(isAdminExist) {
		 	
		    	return new ResponseEntity<Object>("true",HttpStatus.OK);
		 }
		 else
		 {
			 return new ResponseEntity<Object>("false",HttpStatus.OK);
			 
		 }
	 }
	
	@CrossOrigin(origins = "http://localhost:4200")
	 @GetMapping("/adminexistbyname/{name}")
	 public ResponseEntity<Object> isexistByName(@PathVariable String name )
	 {
//	 	 boolean isAdminExist=repo.isexistByName(name);
//		 if(isAdminExist) {
//		 	
//		    	return new ResponseEntity<Object>("true",HttpStatus.OK);
//		 }
//		 else
//		 {
//			 return new ResponseEntity<Object>("false",HttpStatus.OK);
//			 
//		 }
		Optional<AdminDetails> val =  Optional.ofNullable(repo.findByName(name));
		
		if(val.isPresent()) {
			 
				 	
			    	return new ResponseEntity<Object>("true",HttpStatus.OK);
			 }
			 else
			 {
				 return new ResponseEntity<Object>("false",HttpStatus.OK);
				 
			 }
		
			
	 }
	
	@CrossOrigin(origins = "http://localhost:4200")
	 @GetMapping("/packexist/{id}")
	 public ResponseEntity<Object> updatepack(@PathVariable int id )
	 {
	 	 boolean isPackExist=repo1.existsById(id);
		 if(isPackExist) {
		 	
		    	return new ResponseEntity<Object>("true",HttpStatus.OK);
		 }
		 else
		 {
			 return new ResponseEntity<Object>("false",HttpStatus.OK);
			 
		 }
	 }
	
	@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:9991"})
	@PostMapping("/addpack")
	public String savepack(@Valid @RequestBody WashPacks pack)
	{
		repo1.save(pack);
		return " Pack saved successfully with id :"+pack.getId();
	}
	
	@CrossOrigin(origins = {"http://localhost:4200","http://localhost:8080"})
	@GetMapping("/allpacks")
	public List<WashPacks> getpack()
	{
		return repo1.findAll();
	}
	
	
	@CrossOrigin(origins = {"http://localhost:4200","http://localhost:9090"})
	@GetMapping("/allpacks/{id}")
	public Optional<WashPacks> getpack(@PathVariable int id)
	{
		System.out.println(repo1.findById(id));
		return repo1.findById(id);
	}
	
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/packcost/{id}")
	public int getpackcost(@PathVariable int id)
	{
		System.out.println(repo1.findById(id));
		Optional<WashPacks> opt = repo1.findById(id);
		WashPacks pack = opt.get();
		return pack.getCost();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deletepack/{id}")
	public String deletepack(@PathVariable int id)
	{
		repo1.deleteById(id);
		return "pack deleted with id "+id;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/delete/{id}")
	public String delete(@PathVariable int id)
	{
		repo.deleteById(id);
		return "admin deleted with id "+id;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@DeleteMapping("/deleterating/{id}")
	public String deleterating(@PathVariable int id)
	{
		repo2.deleteById(id);
		return "Rating deleted with id "+id;
	}
	
	@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:8080"})
	@PostMapping("/addrating")
	public String saverating(@Valid @RequestBody Ratings rating)
	{
		repo2.save(rating);
		return " Thanks for Your Valuable feedback";
	}
	
	@CrossOrigin(origins = { "http://localhost:4200","http://localhost:8080"})
	@GetMapping("/allratings")
	public List<Ratings> getratings()
	{
		return repo2.findAll();
	}
			
	
//	@CrossOrigin(origins = "http://localhost:4200")
//	@PostMapping("/addwasher")
//	public String savewasher(@RequestBody WasherDetails washer)
//	{
//		repo3.save(washer);
//		return " washer saved successfully with id :"+washer.getId();
//	}

	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addwasher")
	public String addwasher(@Valid @RequestBody WasherDetails washer) throws RestClientException,IOException {
		
		String baseurl="http://localhost:9090/washer/addwasher";
//		HttpHeaders headers = new HttpHeaders();
//		headers.set("MyResponseHeader", "MyValue");
	    HttpEntity<WasherDetails> request = new HttpEntity<>(washer);
	     
		RestTemplate restTemplate=new RestTemplate();
		ResponseEntity<String> response=null;
		try {
		response = restTemplate.exchange(baseurl, HttpMethod.POST, request, String.class);
		}catch(Exception ex)
		{
			System.out.println(ex);
		}
		System.out.println(response.getBody());
		
		return response.getBody().toString();
	
	}
	private HttpEntity<?> getHeaders() throws IOException{
		HttpHeaders headers=new HttpHeaders();
		headers.set("Accept",MediaType.APPLICATION_JSON_VALUE);
		return new HttpEntity<>(headers);
		
	}
			
}
