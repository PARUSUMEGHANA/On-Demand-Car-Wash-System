package io.carwashsystem.washerservice.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.carwashsystem.washerservice.model.WasherDetails;
import io.carwashsystem.washerservice.service.WasherService;
@ExtendWith(MockitoExtension.class)
public class WasherControllerTests {
	@Autowired
	 private MockMvc mockMvc;
	
	@Mock
	private WasherService service;
	private WasherDetails washer;
	
	@InjectMocks
	private WasherController washerController;
	
	
	@BeforeEach
	 public void setUp() {
		 washer = new WasherDetails(17, "Poojitha", "Chennai", "Poojitha123");
		 mockMvc= MockMvcBuilders.standaloneSetup(washerController).build();
	 }
	@Test
    public void addWasherControllerTest() throws Exception {
       
        	when(service.addWasher(any())).thenReturn(washer);
        mockMvc.perform(post("/washer/addwasher")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(washer)))
                .andExpect(status().isCreated());
        verify(service, times(1)).addWasher(any());
    }
	 public static String asJsonString(final Object obj){
	        try{
	            return new ObjectMapper().writeValueAsString(obj);
	        }catch(Exception e){
	            throw new RuntimeException(e);
	        }
	    }
}
