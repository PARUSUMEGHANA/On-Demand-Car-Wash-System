package io.carwashsystem.orderservice;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.springframework.boot.test.context.SpringBootTest;

import io.carwashsystem.orderservice.model.OrderDetails;
import io.carwashsystem.orderservice.repo.OrderRepository;
import io.carwashsystem.orderservice.service.OrderService;

@SpringBootTest
class OrderserviceApplicationTests {

	@Mock
	OrderRepository repository;
	
	@InjectMocks
	OrderService orderService;
	
	
	public List<OrderDetails> myorders;
	
	@Test
	public void test_getOrders() {
		List<OrderDetails> myorders = new ArrayList<OrderDetails>();
		myorders.add(new OrderDetails(25,1,"Swing","Sg125","TejaKrishna",1,"27-9-76","9864095446",50));
		myorders.add(new OrderDetails(22,2,"Sw","Sg","Teja",2,"27-9-76","8745631098",50));
		
		when(repository.findAll()).thenReturn(myorders);
		assertEquals(2,orderService.getorder().size());
	}
	
	@Test
	public void test_addorder() {
		OrderDetails order = new OrderDetails(21,3,"S","S123","Teju",3,"27-9-76","1234567890",50);
		
		when(repository.save(order)).thenReturn(order);
		assertEquals(order,orderService.addorder(order));
	}
	
	@Test
	public void test_deleteOrder() {
		OrderDetails order = new OrderDetails(21,3,"S","S123","Teju",3,"27-9-76","1234567890",50);
		
		orderService.deleteUser(order);
		verify(repository,times(1)).delete(order);
	}



}
