package io.carwashsystem.orderservice.repo;


import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import io.carwashsystem.orderservice.model.OrderDetails;

public interface OrderRepository extends MongoRepository<OrderDetails, Integer> {

	@Query(value = "{ 'userId' : ?0}")
    List<OrderDetails> findByUserId(int userId);
}
