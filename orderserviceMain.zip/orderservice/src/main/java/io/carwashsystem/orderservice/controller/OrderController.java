package io.carwashsystem.orderservice.controller;

import java.util.List;
import java.util.NoSuchElementException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import io.carwashsystem.orderservice.exception.ApiRequestException;
import io.carwashsystem.orderservice.model.OrderDetails;
import io.carwashsystem.orderservice.repo.OrderRepository;
import io.carwashsystem.orderservice.service.OrderService;


@RestController
@RequestMapping("/order")
public class OrderController {
	
	@Autowired
	private OrderRepository repo;
	
	@Autowired
	private OrderService service;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@PostMapping("/addorder")
//	 public String addorder( @RequestBody OrderDetails order) {
//	 	service.addorder(order);
//	 	return "Order is Placed with Washer and will be Proceesed soon "
//	 			+order;
//	 }
	public ResponseEntity<String> addorder(@Valid @RequestBody OrderDetails order) {
		System.out.println("Controller " + order);
		try {
	 		System.out.println("Controller " + order);
	 		order = service.addorder(order);
	 		String result = "Order is Placed with Washer and will be Proceesed soon " + order;
	 		return new ResponseEntity<String>(result, HttpStatus.CREATED);
	 	}
	 	catch(NoSuchElementException e){
	 		return new ResponseEntity<>(HttpStatus.CONFLICT);
	 		
	 	}
	 }
	
	@CrossOrigin(origins = "http://localhost:4200")
	 @PutMapping("/update/orderStatus/{id}")
	 public ResponseEntity<Object> updateorderStatus(@PathVariable int id,  @RequestBody OrderDetails order )
	 {
	 	 boolean isUserExist=repo.existsById(id);
		 if(isUserExist) {
		 	repo.save(order);
		    	return new ResponseEntity<Object>("orderStatus Updated Successfully with id "+id,HttpStatus.OK);
		 }
		 else
		 {
			 throw new ApiRequestException("CAN NOT UPDATE AS order NOT FOUND WITH THIS ID ::");
		 }
	 }
	

	@CrossOrigin(origins = "http://localhost:4200")
	 @PutMapping("/update/ordercost/{id}")
	 public ResponseEntity<Object> updateordercost(@PathVariable int id,  @RequestBody OrderDetails order )
	 {
	 	 boolean isUserExist=repo.existsById(id);
		 if(isUserExist) {
		 	repo.save(order);
		    	return new ResponseEntity<Object>("ordercost updated Successfully with id "+id,HttpStatus.OK);
		 }
		 else
		 {
			 throw new ApiRequestException("CAN NOT UPDATE AS order NOT FOUND WITH THIS ID ::");
		 }
	 }
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/getuserorders/{id}")
	public List<OrderDetails> getorderbyuserid(@PathVariable int id)
	{
		return repo.findByUserId(id);
	}

//	@GetMapping("/allorders")
//	public List<OrderDetails> getorder()
//	{
//		return repo.findAll();
//	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@GetMapping("/allorders")
	public ResponseEntity<List<OrderDetails>> getorder(){
        return new ResponseEntity<List<OrderDetails>>((List<OrderDetails>)service.getorder(),HttpStatus.OK);
    }
	
	@CrossOrigin(origins = "http://localhost:4200")
	 @DeleteMapping("/delete/{id}")
	 public ResponseEntity<Object> deletorder(@PathVariable int id)
	 {
		 boolean isOrderExist=repo.existsById(id);
		 if(isOrderExist) {
			 service.deleteById(id);
			 return new ResponseEntity<Object>("Order deleted with id "+id,HttpStatus.OK);
		 }
		 else
		 {
			 throw new ApiRequestException("CAN NOT DELETE ORDER,AS ORDER NOT FOUND WITH THIS ID ::");
		 }
	 }
			
}
