package io.carwashsystem.orderservice.model;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;


@Document(collection="Orderdetails")
public class OrderDetails {
	
	@Id
	int orderId;
	
	
	int userId;
	
	int cost;
	
	@NotEmpty(message = "carName must not be empty")
	String carName;

	@NotEmpty(message = "car model must not be empty")
	String carModel;
	
	@NotEmpty(message = "Washer Name must not be empty")
	String washerName;

	
	int washpackId;

	@NotEmpty(message = "date must not be empty")
	String date;
	
	@Size(min=10, message="Enter your 10 digit Phone Number Correctly")
	String phoneNo;
	
	@Field
	String orderStatus = "Pending...";
	
	
	public OrderDetails() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public OrderDetails(int i,int p, String string, String string2, String string3, int j, String k, String l, int m) {
		// TODO Auto-generated constructor stub
		super();
		this.orderId = i;
		this.userId = p;
		this.carName = string;
		this.carModel = string2;
		this.washerName = string3;
		this.washpackId = j;
		this.date = k;
		this.phoneNo = l;
		this.cost = m;
	}
	
	

	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getcost() {
		return cost;
	}
	public void setcost(int cost) {
		this.cost = cost;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	public String getCarName() {
		return carName;
	}
	public void setCarName(String carName) {
		this.carName = carName;
	}
	public String getCarModel() {
		return carModel;
	}
	public void setCarModel(String carModel) {
		this.carModel = carModel;
	}
	public String getWasherName() {
		return washerName;
	}
	public void setWasherName(String washerName) {
		this.washerName = washerName;
	}
	public int getWashpackId() {
		return washpackId;
	}
	public void setWashpackId(int washpackId) {
		this.washpackId = washpackId;
	}
	public String getOrderStatus() {
		return orderStatus;
	}
	public void setOrderStatus(String orderStatus) {
		this.orderStatus=orderStatus;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public String getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "OrderDetails [orderId=" + orderId + ",userId=" + userId + ", carName=" + carName + ", carModel=" + carModel + ", washerName="
				+ washerName + ", washpackId=" + washpackId + ", date=" + date + ", phoneNo=" + phoneNo + ", cost=" + cost +", orderStatus=" + orderStatus +"]";
	}
	
	
}

	
	