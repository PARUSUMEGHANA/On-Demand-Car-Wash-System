package io.carwashsystem.userservice.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultHandlers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.carwashsystem.userservice.model.Userdetails;
import io.carwashsystem.userservice.service.UserService;
@ExtendWith(MockitoExtension.class)
public class UsercontrollerTests {
	
	 @Autowired
	 private MockMvc mockMvc;
	 
	 @Mock
	 private UserService service;
	 private Userdetails user;
	 private List<Userdetails> userList;
	 
	 @InjectMocks
	 private UserController userController;
	 
	 @BeforeEach
	 public void setUp() {
		 user = new Userdetails(17, "Poojitha", "Chennai", "Poojitha123");
		 mockMvc= MockMvcBuilders.standaloneSetup(userController).build();
	 }
	 
	 @Test
	    public void addUserControllerTest() throws Exception {
	       
	        	when(service.addUser(any())).thenReturn(user);
	        mockMvc.perform(post("/user/adduser")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(asJsonString(user)))
	                .andExpect(status().isCreated());
	        verify(service, times(1)).addUser(any());
	    }
	 
	 @Test
	    public void getUserControllerTest() throws Exception{
	        when(service.getUsers()).thenReturn(userList);
	        mockMvc.perform(MockMvcRequestBuilders.get("/user/allusers")
	                .contentType(MediaType.APPLICATION_JSON)
	                .content(asJsonString(user)))
	                .andDo(MockMvcResultHandlers.print());
	        verify(service, times(1)).getUsers();

	    }

	 
	 public static String asJsonString(final Object obj){
	        try{
	            return new ObjectMapper().writeValueAsString(obj);
	        }catch(Exception e){
	            throw new RuntimeException(e);
	        }
	    }	 
}
